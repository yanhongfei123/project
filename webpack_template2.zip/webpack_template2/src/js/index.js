import "../css/reset.css";
import "../css/index.css";
import "../css/idangerous.swiper.css";
import "./libs/rem.js";

import $ from "./libs/jquery203.js";
import touch from  "./libs/touch.min.js";
import Swiper from "./libs/idangerous.swiper.min.js";

/*
* author: www.somethingwhat.com
*/
var cat = window.cat || {};
cat.touchjs = {
    left: 0,
    top: 0,
    scaleVal: 1,    //缩放
    rotateVal: 0,   //旋转
    curStatus: 0,   //记录当前手势的状态, 0:拖动, 1:缩放, 2:旋转
    //初始化
    init: function ($targetObj, callback) {
        touch.on($targetObj, 'touchstart', function (ev) {
            cat.touchjs.curStatus = 0;
            ev.preventDefault();//阻止默认事件
        });
        if (!window.localStorage.cat_touchjs_data)
            callback(0, 0, 1, 0);
        else {
            var jsonObj = JSON.parse(window.localStorage.cat_touchjs_data);
            cat.touchjs.left = parseFloat(jsonObj.left), cat.touchjs.top = parseFloat(jsonObj.top), cat.touchjs.scaleVal = parseFloat(jsonObj.scale), cat.touchjs.rotateVal = parseFloat(jsonObj.rotate);
            callback(cat.touchjs.left, cat.touchjs.top, cat.touchjs.scaleVal, cat.touchjs.rotateVal);
        }
    },
    //拖动
    drag: function ($targetObj, callback) {
        touch.on($targetObj, 'drag', function (ev) {
            $targetObj.css("left", cat.touchjs.left + ev.x).css("top", cat.touchjs.top + ev.y);
        });
        touch.on($targetObj, 'dragend', function (ev) {
            cat.touchjs.left = cat.touchjs.left + ev.x;
            cat.touchjs.top = cat.touchjs.top + ev.y;
            callback(cat.touchjs.left, cat.touchjs.top);
        });
    },
    //缩放
    scale: function ($targetObj, callback) {
        var initialScale = cat.touchjs.scaleVal || 1;
        var currentScale;
        touch.on($targetObj, 'pinch', function (ev) {
            if (cat.touchjs.curStatus == 2) {
                return;
            }
            cat.touchjs.curStatus = 1;
            currentScale = ev.scale - 1;
            currentScale = initialScale + currentScale;
            cat.touchjs.scaleVal = currentScale;
            var transformStyle = 'scale(' + cat.touchjs.scaleVal + ') rotate(' + cat.touchjs.rotateVal + 'deg)';
            $targetObj.css("transform", transformStyle).css("-webkit-transform", transformStyle);
            callback(cat.touchjs.scaleVal);
        });

        touch.on($targetObj, 'pinchend', function (ev) {
            if (cat.touchjs.curStatus == 2) {
                return;
            }
            initialScale = currentScale;
            cat.touchjs.scaleVal = currentScale;
            callback(cat.touchjs.scaleVal);
        });
    },
    //旋转
    rotate: function ($targetObj, callback) {
        var angle = cat.touchjs.rotateVal || 0;
        touch.on($targetObj, 'rotate', function (ev) {
            if (cat.touchjs.curStatus == 1) {
                return;
            }
            cat.touchjs.curStatus = 2;
            var totalAngle = angle + ev.rotation;
            if (ev.fingerStatus === 'end') {
                angle = angle + ev.rotation;
            }
            cat.touchjs.rotateVal = totalAngle;
            var transformStyle = 'scale(' + cat.touchjs.scaleVal + ') rotate(' + cat.touchjs.rotateVal + 'deg)';
            $targetObj.css("transform", transformStyle).css("-webkit-transform", transformStyle);
            $targetObj.attr('data-rotate', cat.touchjs.rotateVal);
            callback(cat.touchjs.rotateVal);
        });
    }
};

//保存并刷新
function save(l,t) {
    var data = {
        left: l,
        top: t,
      //  scale: cat.touchjs.scaleVal,
      //  rotate: cat.touchjs.rotateVal
    };
    //本地存储
    window.localStorage.cat_touchjs_data = JSON.stringify(data);
   // window.location = window.location;
};



window.onload = function() {
    
  var $targetObj = $("#fatao");
  var left = (parseInt($('.can-wrap')[0].style.width) - $targetObj[0].getAttribute('width'))/2 ;
  var top = 20 ;
  console.log($('.can-wrap')[0].offsetWidth)

  save(left,top)
 //初始化设置
 cat.touchjs.init($targetObj, function (left, top, scale, rotate) {
    $targetObj.css({
        left: left,
        top: top,
        'transform': 'scale(' + scale + ') rotate(' + rotate + 'deg)',
        '-webkit-transform': 'scale(' + scale + ') rotate(' + rotate + 'deg)'
    });
});

  //初始化拖动手势（不需要就注释掉）
  cat.touchjs.drag($targetObj, function(left, top) {
    console.log(left, top);
  });
  //初始化缩放手势（不需要就注释掉）
  cat.touchjs.scale($targetObj, function(scale) {});

//   //初始化旋转手势（不需要就注释掉）
//   cat.touchjs.rotate($targetObj, function(rotate) {});

  var swiper = new Swiper(".swiper-container", {
    pagination: ".swiper-pagination",
    paginationClickable: true,
    direction: "vertical"
  }).on("slideChangeStart", function(o) {
    console.log(o.activeIndex + 1);
    if (o.activeIndex + 1 == 4) {
      $(".slide-btn")
        .addClass("slideDown")
        .removeClass("slideUp");
    } else {
      $(".slide-btn")
        .addClass("slideUp")
        .removeClass("slideDown");
    }
  });
  var canvas = document.getElementById("canvas");
  var fatao = document.getElementById("fatao");
  var context = canvas.getContext("2d");
  var fataoCtx = fatao.getContext("2d");
  var cut = {};
  $("#file").change(function() {
    $(".choose_product").show();
    $(".choose-wrap").hide();
    var file = $("#file")[0].files[0];
    cut.drawImage(window.URL.createObjectURL(file));
    //  document.getElementById('preImg').src = window.URL.createObjectURL(file);
  });
  $(".choose_product").on("click", "div", function() {
    var cls = $(this).attr("data-des");
    $(".choose_product").hide();
    $(".edit-wrap").show();
    $("." + cls + "-wrap").show();
  });

  $(".ft_list").on("click", "img", function() {
    $(this).parent()
      .addClass("active")
      .siblings()
      .removeClass("active");
    var img = new Image();
    console.log($(this)[0].src);
    //  compareImg.crossOrigin = "Anonymous"; //解决跨域
    img.src = $(this)[0].src;

    img.onload = function() {
      fataoCtx.clearRect(0, 0, $('#fatao').width(), $('#fatao').height());
      fataoCtx.drawImage(img, 0, 0, $('#fatao').width(), $('#fatao').height());
    };
  });

  cut.initScaleWidth = function(canvas, imgW, imgH) {
    var w, h;
    if (imgW >= imgH) {
      w = canvas.width;
      h = w * imgH / imgW;
    } else {
      h = canvas.height;
      w = imgW * h / imgH;
    }
    return {
      w: w,
      h: h
    };
  };

  cut.drawImage = function(src) {
    //加载图片
    var image = new Image();
    image.onload = function() {
      var initScale = cut.initScaleWidth(canvas, this.width, this.height);
      context.clearRect(0, 0, 200, 300);
      context.drawImage(
        image,
        0,
        0,
        this.width,
        this.height,
        (canvas.width - initScale.w) / 2,
        (canvas.height - initScale.h) / 2,
        initScale.w,
        initScale.h
      );
    };

    image.src = src;
  };
};

// const welcomeMessage = 'ES6 is awesomefffffffffffff';
// const content = `hello, ${welcomeMessage}`;
// let container = $('#container');
// container.html(content);
// var tpl = require('../handlebars/demo.handlebars');
// var tplData = {
//     datas:[
//         {
//             imgUrl: require('../imgs/aa_01.jpg'),
//             title:'这个图片的地址通过模版插入111',
//             even:true
//         },
//         {
//             imgUrl: require('../imgs/729.gif'),
//             title:'这个图片的地址通过模版插入222'
//         },
//         {
//             imgUrl: require('../imgs/729.gif'),
//             title:'这个图片的地址通过模版插入333'
//         },
//         {
//             imgUrl: require('../imgs/729.gif'),
//             title:'这个图片的地址通过模版插入444'
//         }
//     ]
// };

//  container.append(tpl(tplData));
