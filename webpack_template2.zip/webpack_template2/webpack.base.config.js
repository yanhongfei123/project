const path = require("path");
const fs = require("fs");
const webpack = require("webpack");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const autoprefixer = require("autoprefixer");

//const CleanWebpackPlugin = require('clean-webpack-plugin');
const CopyWebpackPlugin = require("copy-webpack-plugin");



var HappyPack = require('happypack');
var  os = require('os') ;
var  happyThreadPool = HappyPack.ThreadPool({ size: os.cpus().length });


// const vendor = [
//   path.resolve(__dirname, "./src/js/libs/jquery203.js"),
//   path.resolve(__dirname, "./src/js/libs/methods.js"),
//   path.resolve(__dirname, "./src/js/libs/fastclick.js")
// ];


// 源代码的根目录（本地物理文件路径）
const SRC_PATH = path.resolve(__dirname, "./src");
// 打包后的资源根目录（本地物理文件路径）
const BUILD_PATH = path.resolve(__dirname, "./build");
// 资源根目录（可以是 CDN 上的绝对路径，或相对路径）


var plugins = [ ];
var  entrys = getEntry();
//获取项目入口js文件
function getEntry() {
  var jsPath = path.resolve(__dirname, "src/js");
  var dirs = fs.readdirSync(jsPath);
  var matchs = [],  files = {};

  console.log("dirs =====" + JSON.stringify(dirs));

    dirs.forEach(function(item) {
      matchs = item.match(/(.+)\.js$/);
      if (matchs) {
        var entryFileName = matchs[1];

        console.log("matchs =====" + JSON.stringify(matchs));
        console.log("entryFileName ======" + entryFileName);

        files[entryFileName] = path.resolve("src", "js", item);
        /*** 根据目录获取 Html 入口*/
        plugins.push(

          new HtmlWebpackPlugin({
            favicon:'favicon.ico',
            filename:BUILD_PATH + "/page/" + entryFileName + ".html",
            template: SRC_PATH  + "/page/" + entryFileName + ".html",
            chunks: [entryFileName],
            //  excludeChunks: [],
            inject: true,
            minify: {
              //压缩HTML文件
              removeComments: true, //移除HTML中的注释
              collapseWhitespace: true //删除空白符与换行符
            }
          }),
          //   new CopyWebpackPlugin([
          //     // {output}/file.txt
          //     { from: `./src/imgs`,to:`imgs`}
          // ]),
          new CopyWebpackPlugin([
            { from: './dll', to: 'dll' }
          ])
        );
      }
    });

    return   files
    
  }

 // entrys["vendor"] = vendor;

  console.log(entrys)

  plugins.push(
    new webpack.DllReferencePlugin({
      context: __dirname,
      manifest: require('./vendor-manifest.json')
    }),

    // new webpack.optimize.CommonsChunkPlugin({
    //   name: ["vendor", "runtime"],
    //   minChunks: Infinity
    // //  filename: "js/commons.[hash:4].js",
    // }),

    new HappyPack({
      id: 'happybabel',
      loaders: [{
        loader: 'babel-loader',
        query: {
          presets: ["es2015"],
          plugins: [["transform-object-rest-spread"], ["transform-runtime"]]
        }  
    }],
      threadPool: happyThreadPool,
      cache: true,
      verbose: true
    })
  
  )


module.exports = {
  entry: entrys,
  module: {
    loaders: [
      {
        test: /\.js[x]?$/,
        exclude: /node_modules/,
        loader: 'happypack/loader?id=happybabel'
      },

      // {
      //   test: /\.js$/,
      //   exclude: /node_modules/,
      //   loader: "babel-loader",
      //   query: {
      //     presets: ["es2015"],
      //     plugins: [["transform-object-rest-spread"], ["transform-runtime"]]
      //   }
      // },

      {
        // 专供iconfont方案使用的，后面会带一串时间戳，需要特别匹配到
        test: /\.(mp4|mp3|woff|woff2|svg|eot|ttf)\??.*$/,
        include: path.resolve(__dirname, "./src/fonts"),
        // exclude: /glyphicons/,
      //   loader: 'file-loader?name=static/fonts/[name].[ext]',
        loader: "file-loader",
        options: {
          name: "./fonts/[name].[hash:8].[ext]"
        }
      },
      {
        test: /\.handlebars$/,
        include: path.resolve(__dirname, "./src/handlebars"),
        loader: "handlebars-loader"
      }
    ]
  },

  resolve: {
    extensions: [".js", ".scss", ".ts"],
    modules: ["node_modules"],
    alias: {
      jquery: path.resolve(__dirname, "./src/js/libs/jquery203.js"),
      methods: path.resolve(__dirname, "./src/js/libs/methods.js"),
      fastclick: path.resolve(__dirname, "./src/js/libs/fastclick.js"),
      vconsole: path.resolve(__dirname, "./src/js/libs/vconsole.js")
    }
  },
  plugins:plugins,

};
