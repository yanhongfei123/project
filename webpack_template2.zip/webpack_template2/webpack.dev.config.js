const path = require("path");
const webpack = require("webpack");
const config = require("./webpack.base.config");
const BundleAnalyzerPlugin = require("webpack-bundle-analyzer")
  .BundleAnalyzerPlugin;
const commonConfig = require("./webpack.com.config.js");

config.output = {
  path: path.resolve(__dirname, "./build"),
  filename: "js/[name].js",
  publicPath:'/',
  //chunkFilename: 'js/[chunkhash:8].chunk.js'
};


config.module.loaders.push(
  {
    // 图片加载器，雷同file-loader，更适合图片，可以将较小的图片转成base64，减少http请求
    // 如下配置，将小于8192byte的图片转成base64码
    test: /\.(png|jpg|svg|gif)$/,
    use: ["url-loader?limit=8192&name=images/[name].[hash:8].[ext]"],
    include: path.resolve(__dirname, "./src/imgs"),

    // loader: "url-loader",
    // options: {
    //   limit: 10000, //10000
    //   name: "images/[name].[hash:8].[ext]"
    // }
  },
  {
    test: /\.css$/,
    use: [
      "style-loader",
      "css-loader",
      {
        loader: "postcss-loader",
        options: { plugins: [require("autoprefixer")] }
      }
    ]
  },
  {
    test: /\.scss$/,
    use: [
      "style-loader",
      "css-loader",
      {
        loader: "postcss-loader",
        options: { plugins: [require("autoprefixer")] }
      },
      "sass-loader"
    ]
  }
);

console.log(config.module.loaders);

config.devServer = {
  contentBase: "./build",
  host: "localhost",
  port: 9001,
  inline: true, // 可以监控js变化
  hot: true, // 热启动
  compress: true,
  watchContentBase: false
  // proxy: {
  //  '/test/*': {
  //    target: 'http://localhost',
  //    changeOrigin: true,
  //    secure: false
  //  }
  // }
};

config.plugins.push(
  //   new BundleAnalyzerPlugin(),
  new webpack.DefinePlugin({
    "process.env": {
      NODE_ENV: JSON.stringify(commonConfig.dev.env.NODE_ENV)
    }
  }),
  new webpack.HotModuleReplacementPlugin() //热加载插件
);

config.devtool = "source-map";
// config.plugins.push(
//   new webpack.SourceMapDevToolPlugin({
//     filename: '[file].map',
//     exclude: ['vendor.js'] // vendor 通常不需要 sourcemap
//   })
// );

module.exports = config;
