# echarts_extendsMap0302
基于echarts，地图数据展示，点击地图下钻（只下钻到省市）

[点击查看效果](https://littlezong.github.io/echarts_extendsMap0302/)

------

仅供学习参考哦。
